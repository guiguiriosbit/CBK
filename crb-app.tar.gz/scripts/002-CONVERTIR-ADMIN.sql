-- ============================================
-- SCRIPT PARA CONVERTIRSE EN ADMINISTRADOR
-- ============================================
-- IMPORTANTE: Reemplaza 'TU_EMAIL_AQUI' con tu email real
-- ============================================

-- Opción 1: Convertir por email (RECOMENDADO)
UPDATE public.profiles 
SET role = 'admin' 
WHERE email = 'TU_EMAIL_AQUI';

-- Si no sabes tu email, ejecuta esto primero para ver todos los usuarios:
-- SELECT id, email, role FROM public.profiles;

-- Opción 2: Convertir el primer usuario registrado
-- UPDATE public.profiles 
-- SET role = 'admin' 
-- WHERE id = (SELECT id FROM public.profiles ORDER BY created_at ASC LIMIT 1);

-- Verificar que se actualizó correctamente:
-- SELECT id, email, role FROM public.profiles WHERE role = 'admin';



