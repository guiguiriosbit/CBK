-- ============================================
-- SCRIPT DE VERIFICACIÓN Y COMPLETADO
-- Este script verifica qué existe y solo crea/actualiza lo necesario
-- Ejecuta este script si ya tienes algunas tablas creadas
-- ============================================

-- ============================================
-- PARTE 1: AGREGAR COLUMNA ROLE SI NO EXISTE
-- ============================================

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'public' 
    AND table_name = 'profiles' 
    AND column_name = 'role'
  ) THEN
    ALTER TABLE public.profiles ADD COLUMN role TEXT DEFAULT 'cliente';
    RAISE NOTICE 'Columna role agregada a profiles';
  ELSE
    RAISE NOTICE 'Columna role ya existe en profiles';
  END IF;
END $$;

-- ============================================
-- PARTE 2: CREAR TABLA TRANSACTIONS SI NO EXISTE
-- ============================================

CREATE TABLE IF NOT EXISTS public.transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  order_id UUID REFERENCES public.orders(id) ON DELETE SET NULL,
  stripe_payment_intent_id TEXT NOT NULL UNIQUE,
  amount DECIMAL(10, 2) NOT NULL,
  currency TEXT NOT NULL DEFAULT 'mxn',
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'succeeded', 'failed', 'refunded')),
  description TEXT,
  metadata JSONB,
  completed_at TIMESTAMP WITH TIME ZONE,
  failed_at TIMESTAMP WITH TIME ZONE,
  refunded_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- PARTE 3: CREAR ÍNDICES SI NO EXISTEN
-- ============================================

CREATE INDEX IF NOT EXISTS idx_transactions_user ON public.transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_order ON public.transactions(order_id);
CREATE INDEX IF NOT EXISTS idx_transactions_stripe_id ON public.transactions(stripe_payment_intent_id);
CREATE INDEX IF NOT EXISTS idx_transactions_status ON public.transactions(status);

-- ============================================
-- PARTE 4: CREAR FUNCIÓN update_updated_at SI NO EXISTE
-- ============================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- PARTE 5: CREAR TRIGGER PARA TRANSACTIONS SI NO EXISTE
-- ============================================

DROP TRIGGER IF EXISTS update_transactions_updated_at ON public.transactions;
CREATE TRIGGER update_transactions_updated_at 
  BEFORE UPDATE ON public.transactions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- PARTE 6: HABILITAR RLS EN TRANSACTIONS SI NO ESTÁ HABILITADO
-- ============================================

ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

-- ============================================
-- PARTE 7: CREAR POLÍTICAS RLS PARA TRANSACTIONS
-- ============================================

-- Eliminar políticas existentes si hay
DROP POLICY IF EXISTS "Los usuarios pueden ver sus propias transacciones" ON public.transactions;
DROP POLICY IF EXISTS "Los usuarios pueden crear sus propias transacciones" ON public.transactions;

-- Crear políticas
CREATE POLICY "Los usuarios pueden ver sus propias transacciones"
  ON public.transactions FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Los usuarios pueden crear sus propias transacciones"
  ON public.transactions FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- ============================================
-- PARTE 8: VERIFICAR Y CREAR FUNCIÓN handle_new_user
-- ============================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name')
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Crear trigger si no existe
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================
-- PARTE 9: CREAR VISTAS SI NO EXISTEN
-- ============================================

-- Vista para administradores
CREATE OR REPLACE VIEW public.admin_orders_view AS
SELECT 
  o.id,
  o.user_id,
  p.email,
  p.full_name,
  o.total_amount,
  o.status,
  o.payment_status,
  o.created_at,
  o.updated_at,
  sa.address_line1,
  sa.city,
  sa.state,
  sa.postal_code
FROM public.orders o
LEFT JOIN public.profiles p ON o.user_id = p.id
LEFT JOIN public.shipping_addresses sa ON o.shipping_address_id = sa.id;

-- Vista para estadísticas de productos
CREATE OR REPLACE VIEW public.product_stats AS
SELECT 
  p.id,
  p.name,
  p.price,
  p.stock,
  p.is_active,
  c.name as category_name,
  COALESCE(SUM(oi.quantity), 0) as total_sold,
  COALESCE(SUM(oi.subtotal), 0) as total_revenue
FROM public.products p
LEFT JOIN public.categories c ON p.category_id = c.id
LEFT JOIN public.order_items oi ON p.id = oi.product_id
GROUP BY p.id, p.name, p.price, p.stock, p.is_active, c.name;

-- ============================================
-- PARTE 10: VERIFICAR POLÍTICAS RLS EXISTENTES
-- ============================================

-- Verificar que las políticas principales existan para categories y products
DO $$
BEGIN
  -- Política para categories (lectura pública)
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'categories' 
    AND policyname = 'Todos pueden ver categorías'
  ) THEN
    CREATE POLICY "Todos pueden ver categorías"
      ON public.categories FOR SELECT
      TO public
      USING (true);
    RAISE NOTICE 'Política de categorías creada';
  END IF;

  -- Política para products (lectura pública de productos activos)
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'products' 
    AND policyname = 'Todos pueden ver productos activos'
  ) THEN
    CREATE POLICY "Todos pueden ver productos activos"
      ON public.products FOR SELECT
      TO public
      USING (is_active = true);
    RAISE NOTICE 'Política de productos creada';
  END IF;
END $$;

-- ============================================
-- PARTE 11: INSERTAR DATOS DE PRUEBA (SOLO SI NO EXISTEN)
-- ============================================

-- Insertar categorías solo si no existen
INSERT INTO public.categories (name, description, image_url) 
SELECT * FROM (VALUES
  ('Árboles de Navidad', 'Árboles artificiales y naturales de todos los tamaños', '/placeholder.svg?height=300&width=300'),
  ('Luces Navideñas', 'Luces LED y tradicionales para interior y exterior', '/placeholder.svg?height=300&width=300'),
  ('Bolas y Ornamentos', 'Decoraciones colgantes para el árbol', '/placeholder.svg?height=300&width=300'),
  ('Coronas', 'Coronas decorativas para puertas y paredes', '/placeholder.svg?height=300&width=300'),
  ('Belenes y Figuras', 'Nacimientos y figuras navideñas', '/placeholder.svg?height=300&width=300'),
  ('Decoración de Mesa', 'Manteles, centros de mesa y vajilla navideña', '/placeholder.svg?height=300&width=300')
) AS v(name, description, image_url)
WHERE NOT EXISTS (SELECT 1 FROM public.categories WHERE categories.name = v.name);

-- Insertar productos de ejemplo solo si no existen productos
DO $$
DECLARE
  product_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO product_count FROM public.products;
  
  IF product_count = 0 THEN
    -- Insertar productos de ejemplo
    INSERT INTO public.products (name, description, price, stock, category_id, image_url, featured) 
    SELECT 
      'Árbol de Navidad Premium 2.1m',
      'Árbol artificial de alta calidad con ramas densas y aspecto natural. Incluye base metálica resistente.',
      2499.00,
      15,
      c.id,
      '/placeholder.svg?height=400&width=400',
      true
    FROM public.categories c WHERE c.name = 'Árboles de Navidad';

    INSERT INTO public.products (name, description, price, stock, category_id, image_url, featured)
    SELECT 
      'Luces LED Multicolor 200 Focos',
      'Serie de 200 luces LED de bajo consumo con 8 modos de iluminación. Cable verde de 20m.',
      449.00,
      50,
      c.id,
      '/placeholder.svg?height=400&width=400',
      true
    FROM public.categories c WHERE c.name = 'Luces Navideñas';

    INSERT INTO public.products (name, description, price, stock, category_id, image_url, featured)
    SELECT 
      'Set 24 Bolas Navideñas Rojas y Doradas',
      'Conjunto de 24 bolas decorativas en tonos rojo y dorado. Material inastillable, ideal para hogares con niños.',
      299.00,
      80,
      c.id,
      '/placeholder.svg?height=400&width=400',
      true
    FROM public.categories c WHERE c.name = 'Bolas y Ornamentos';

    RAISE NOTICE 'Productos de ejemplo insertados';
  ELSE
    RAISE NOTICE 'Ya existen productos en la base de datos, omitiendo inserción';
  END IF;
END $$;

-- ============================================
-- FIN DEL SCRIPT
-- ============================================
-- 
-- Este script es seguro de ejecutar múltiples veces
-- Solo crea/actualiza lo que falta
-- 
-- IMPORTANTE: Después de ejecutar este script:
-- 1. Ve a Authentication > Users en el dashboard de Supabase
-- 2. Encuentra tu usuario y copia su email
-- 3. Ejecuta este comando SQL para convertirte en administrador:
--    UPDATE public.profiles SET role = 'admin' WHERE email = 'TU_EMAIL_AQUI';
-- ============================================



