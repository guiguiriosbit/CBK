-- ============================================
-- SCRIPT COMPLETO DE CONFIGURACIÓN DE BASE DE DATOS
-- Adornos CBK - Supabase
-- ============================================
-- Ejecuta este script completo en el SQL Editor de Supabase
-- ============================================

-- ============================================
-- PARTE 1: CREAR TABLAS
-- ============================================

-- Tabla de perfiles de usuario (extiende auth.users de Supabase)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  phone TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabla de direcciones de envío
CREATE TABLE IF NOT EXISTS public.shipping_addresses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  address_line1 TEXT NOT NULL,
  address_line2 TEXT,
  city TEXT NOT NULL,
  state TEXT NOT NULL,
  postal_code TEXT NOT NULL,
  country TEXT NOT NULL DEFAULT 'México',
  is_default BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabla de categorías de productos
CREATE TABLE IF NOT EXISTS public.categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  image_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabla de productos
CREATE TABLE IF NOT EXISTS public.products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  stock INTEGER NOT NULL DEFAULT 0,
  category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL,
  image_url TEXT,
  is_active BOOLEAN DEFAULT true,
  featured BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabla de pedidos
CREATE TABLE IF NOT EXISTS public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  shipping_address_id UUID REFERENCES public.shipping_addresses(id),
  total_amount DECIMAL(10, 2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'shipped', 'delivered', 'cancelled')),
  payment_status TEXT NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'paid', 'failed', 'refunded')),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabla de items de pedido
CREATE TABLE IF NOT EXISTS public.order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.products(id),
  quantity INTEGER NOT NULL,
  unit_price DECIMAL(10, 2) NOT NULL,
  subtotal DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabla de carrito de compras
CREATE TABLE IF NOT EXISTS public.cart_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  quantity INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, product_id)
);

-- Tabla de transacciones para Stripe
CREATE TABLE IF NOT EXISTS public.transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  order_id UUID REFERENCES public.orders(id) ON DELETE SET NULL,
  stripe_payment_intent_id TEXT NOT NULL UNIQUE,
  amount DECIMAL(10, 2) NOT NULL,
  currency TEXT NOT NULL DEFAULT 'mxn',
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'succeeded', 'failed', 'refunded')),
  description TEXT,
  metadata JSONB,
  completed_at TIMESTAMP WITH TIME ZONE,
  failed_at TIMESTAMP WITH TIME ZONE,
  refunded_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- PARTE 2: ÍNDICES PARA RENDIMIENTO
-- ============================================

CREATE INDEX IF NOT EXISTS idx_products_category ON public.products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_featured ON public.products(featured) WHERE featured = true;
CREATE INDEX IF NOT EXISTS idx_orders_user ON public.orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_cart_items_user ON public.cart_items(user_id);
CREATE INDEX IF NOT EXISTS idx_shipping_addresses_user ON public.shipping_addresses(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_user ON public.transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_order ON public.transactions(order_id);
CREATE INDEX IF NOT EXISTS idx_transactions_stripe_id ON public.transactions(stripe_payment_intent_id);
CREATE INDEX IF NOT EXISTS idx_transactions_status ON public.transactions(status);

-- ============================================
-- PARTE 3: FUNCIONES Y TRIGGERS
-- ============================================

-- Función para actualizar updated_at automáticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers para actualizar updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON public.products
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON public.orders
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_cart_items_updated_at BEFORE UPDATE ON public.cart_items
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_transactions_updated_at BEFORE UPDATE ON public.transactions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Función para crear perfil automáticamente cuando se registra un usuario
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger para crear perfil automáticamente
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================
-- PARTE 4: AGREGAR COLUMNA DE ROL
-- ============================================

-- Añade la columna de rol a la tabla profiles (si no existe)
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'public' 
    AND table_name = 'profiles' 
    AND column_name = 'role'
  ) THEN
    ALTER TABLE public.profiles ADD COLUMN role TEXT DEFAULT 'cliente';
  END IF;
END $$;

-- ============================================
-- PARTE 5: ROW LEVEL SECURITY (RLS)
-- ============================================

-- Habilitar Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shipping_addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cart_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

-- Políticas para profiles
DROP POLICY IF EXISTS "Los usuarios pueden ver su propio perfil" ON public.profiles;
CREATE POLICY "Los usuarios pueden ver su propio perfil"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

DROP POLICY IF EXISTS "Los usuarios pueden actualizar su propio perfil" ON public.profiles;
CREATE POLICY "Los usuarios pueden actualizar su propio perfil"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

DROP POLICY IF EXISTS "Los usuarios pueden insertar su propio perfil" ON public.profiles;
CREATE POLICY "Los usuarios pueden insertar su propio perfil"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

-- Políticas para shipping_addresses
DROP POLICY IF EXISTS "Los usuarios pueden ver sus propias direcciones" ON public.shipping_addresses;
CREATE POLICY "Los usuarios pueden ver sus propias direcciones"
  ON public.shipping_addresses FOR SELECT
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Los usuarios pueden crear sus propias direcciones" ON public.shipping_addresses;
CREATE POLICY "Los usuarios pueden crear sus propias direcciones"
  ON public.shipping_addresses FOR INSERT
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Los usuarios pueden actualizar sus propias direcciones" ON public.shipping_addresses;
CREATE POLICY "Los usuarios pueden actualizar sus propias direcciones"
  ON public.shipping_addresses FOR UPDATE
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Los usuarios pueden eliminar sus propias direcciones" ON public.shipping_addresses;
CREATE POLICY "Los usuarios pueden eliminar sus propias direcciones"
  ON public.shipping_addresses FOR DELETE
  USING (auth.uid() = user_id);

-- Políticas para categories (todos pueden leer)
DROP POLICY IF EXISTS "Todos pueden ver categorías" ON public.categories;
CREATE POLICY "Todos pueden ver categorías"
  ON public.categories FOR SELECT
  TO public
  USING (true);

-- Políticas para products (todos pueden leer productos activos)
DROP POLICY IF EXISTS "Todos pueden ver productos activos" ON public.products;
CREATE POLICY "Todos pueden ver productos activos"
  ON public.products FOR SELECT
  TO public
  USING (is_active = true);

-- Políticas para orders
DROP POLICY IF EXISTS "Los usuarios pueden ver sus propios pedidos" ON public.orders;
CREATE POLICY "Los usuarios pueden ver sus propios pedidos"
  ON public.orders FOR SELECT
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Los usuarios pueden crear sus propios pedidos" ON public.orders;
CREATE POLICY "Los usuarios pueden crear sus propios pedidos"
  ON public.orders FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Políticas para order_items
DROP POLICY IF EXISTS "Los usuarios pueden ver items de sus pedidos" ON public.order_items;
CREATE POLICY "Los usuarios pueden ver items de sus pedidos"
  ON public.order_items FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Los usuarios pueden crear items de sus pedidos" ON public.order_items;
CREATE POLICY "Los usuarios pueden crear items de sus pedidos"
  ON public.order_items FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

-- Políticas para cart_items
DROP POLICY IF EXISTS "Los usuarios pueden ver su propio carrito" ON public.cart_items;
CREATE POLICY "Los usuarios pueden ver su propio carrito"
  ON public.cart_items FOR SELECT
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Los usuarios pueden crear items en su carrito" ON public.cart_items;
CREATE POLICY "Los usuarios pueden crear items en su carrito"
  ON public.cart_items FOR INSERT
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Los usuarios pueden actualizar items de su carrito" ON public.cart_items;
CREATE POLICY "Los usuarios pueden actualizar items de su carrito"
  ON public.cart_items FOR UPDATE
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Los usuarios pueden eliminar items de su carrito" ON public.cart_items;
CREATE POLICY "Los usuarios pueden eliminar items de su carrito"
  ON public.cart_items FOR DELETE
  USING (auth.uid() = user_id);

-- Políticas para transactions
DROP POLICY IF EXISTS "Los usuarios pueden ver sus propias transacciones" ON public.transactions;
CREATE POLICY "Los usuarios pueden ver sus propias transacciones"
  ON public.transactions FOR SELECT
  USING (auth.uid() = user_id);

-- ============================================
-- PARTE 6: VISTAS PARA ADMINISTRADORES
-- ============================================

-- Vista para administradores (listado completo de pedidos con información del usuario)
CREATE OR REPLACE VIEW public.admin_orders_view AS
SELECT 
  o.id,
  o.user_id,
  p.email,
  p.full_name,
  o.total_amount,
  o.status,
  o.payment_status,
  o.created_at,
  o.updated_at,
  sa.address_line1,
  sa.city,
  sa.state,
  sa.postal_code
FROM public.orders o
LEFT JOIN public.profiles p ON o.user_id = p.id
LEFT JOIN public.shipping_addresses sa ON o.shipping_address_id = sa.id;

-- Vista para estadísticas de productos
CREATE OR REPLACE VIEW public.product_stats AS
SELECT 
  p.id,
  p.name,
  p.price,
  p.stock,
  p.is_active,
  c.name as category_name,
  COALESCE(SUM(oi.quantity), 0) as total_sold,
  COALESCE(SUM(oi.subtotal), 0) as total_revenue
FROM public.products p
LEFT JOIN public.categories c ON p.category_id = c.id
LEFT JOIN public.order_items oi ON p.id = oi.product_id
GROUP BY p.id, p.name, p.price, p.stock, p.is_active, c.name;

-- ============================================
-- PARTE 7: DATOS DE PRUEBA (OPCIONAL)
-- ============================================

-- Insertar categorías de adornos navideños
INSERT INTO public.categories (name, description, image_url) VALUES
  ('Árboles de Navidad', 'Árboles artificiales y naturales de todos los tamaños', '/placeholder.svg?height=300&width=300'),
  ('Luces Navideñas', 'Luces LED y tradicionales para interior y exterior', '/placeholder.svg?height=300&width=300'),
  ('Bolas y Ornamentos', 'Decoraciones colgantes para el árbol', '/placeholder.svg?height=300&width=300'),
  ('Coronas', 'Coronas decorativas para puertas y paredes', '/placeholder.svg?height=300&width=300'),
  ('Belenes y Figuras', 'Nacimientos y figuras navideñas', '/placeholder.svg?height=300&width=300'),
  ('Decoración de Mesa', 'Manteles, centros de mesa y vajilla navideña', '/placeholder.svg?height=300&width=300')
ON CONFLICT (name) DO NOTHING;

-- Insertar productos de ejemplo
INSERT INTO public.products (name, description, price, stock, category_id, image_url, featured) 
SELECT 
  'Árbol de Navidad Premium 2.1m',
  'Árbol artificial de alta calidad con ramas densas y aspecto natural. Incluye base metálica resistente.',
  2499.00,
  15,
  c.id,
  '/placeholder.svg?height=400&width=400',
  true
FROM public.categories c WHERE c.name = 'Árboles de Navidad'
ON CONFLICT DO NOTHING;

INSERT INTO public.products (name, description, price, stock, category_id, image_url, featured)
SELECT 
  'Luces LED Multicolor 200 Focos',
  'Serie de 200 luces LED de bajo consumo con 8 modos de iluminación. Cable verde de 20m.',
  449.00,
  50,
  c.id,
  '/placeholder.svg?height=400&width=400',
  true
FROM public.categories c WHERE c.name = 'Luces Navideñas'
ON CONFLICT DO NOTHING;

INSERT INTO public.products (name, description, price, stock, category_id, image_url, featured)
SELECT 
  'Set 24 Bolas Navideñas Rojas y Doradas',
  'Conjunto de 24 bolas decorativas en tonos rojo y dorado. Material inastillable, ideal para hogares con niños.',
  299.00,
  80,
  c.id,
  '/placeholder.svg?height=400&width=400',
  true
FROM public.categories c WHERE c.name = 'Bolas y Ornamentos'
ON CONFLICT DO NOTHING;

INSERT INTO public.products (name, description, price, stock, category_id, image_url)
SELECT 
  'Corona Navideña Natural 45cm',
  'Corona hecha a mano con ramas naturales, piñas y bayas rojas. Decoración elegante para puertas.',
  599.00,
  25,
  c.id,
  '/placeholder.svg?height=400&width=400'
FROM public.categories c WHERE c.name = 'Coronas'
ON CONFLICT DO NOTHING;

INSERT INTO public.products (name, description, price, stock, category_id, image_url)
SELECT 
  'Nacimiento 12 Piezas Resina',
  'Belén completo con 12 figuras detalladas en resina pintada a mano. Altura aprox. 15cm.',
  1299.00,
  20,
  c.id,
  '/placeholder.svg?height=400&width=400'
FROM public.categories c WHERE c.name = 'Belenes y Figuras'
ON CONFLICT DO NOTHING;

INSERT INTO public.products (name, description, price, stock, category_id, image_url)
SELECT 
  'Centro de Mesa Navideño con Velas',
  'Elegante centro de mesa con velas LED, ramas de pino y decoración navideña. 40cm de largo.',
  449.00,
  30,
  c.id,
  '/placeholder.svg?height=400&width=400'
FROM public.categories c WHERE c.name = 'Decoración de Mesa'
ON CONFLICT DO NOTHING;

-- ============================================
-- FIN DEL SCRIPT
-- ============================================
-- 
-- IMPORTANTE: Después de ejecutar este script:
-- 1. Ve a Authentication > Users en el dashboard de Supabase
-- 2. Encuentra tu usuario y copia su email
-- 3. Ejecuta este comando SQL para convertirte en administrador:
--    UPDATE public.profiles SET role = 'admin' WHERE email = 'TU_EMAIL_AQUI';
-- ============================================



